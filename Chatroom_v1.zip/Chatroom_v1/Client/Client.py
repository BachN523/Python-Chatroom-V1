import socket
import sys

SERVER_PORT = 16043  # 1 plus the last four digits of your student ID
MAX_LINE = 256

def get_ip_address(host):
    try:
        # If the user input is an alpha name for the host, use gethostbyname()
        # If not, get host by addr (assume IPv4)
        socket.inet_aton(host)
        return host
    except socket.error:
        try:
            return socket.gethostbyname(host)
        except socket.gaierror:
            print("Host not found")
            return None

def main():
    if len(sys.argv) < 2:
        print("\nUseage: client serverName")
        return

    server_name = sys.argv[1]
    ip_address = get_ip_address(server_name)
    if not ip_address:
        return

    try:
        # Create a socket.
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except socket.error as e:
        print(f"Error at socket(): {e}")
        return

    try:
        # Connect to a server.
        s.connect((ip_address, SERVER_PORT))
    except socket.error as e:
        print(f"Failed to connect: {e}")
        s.close()
        return

    try:
        # Send and receive data.
        print("Type whatever you want: ", end='', flush=True)
        message = input()
        s.sendall(message.encode())
        data = s.recv(MAX_LINE)
        print(f"Server says: {data.decode().strip()}")
    except socket.error as e:
        print(f"Error in data exchange: {e}")
    finally:
        s.close()

if __name__ == "__main__":
    main()
