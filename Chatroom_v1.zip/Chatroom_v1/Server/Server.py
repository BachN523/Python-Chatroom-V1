# Well, I don't need to explicitly use Windows-specific functions like in \C skeletons
# Exception handling will be used instead of return values
# 
import socket
import sys

SERVER_PORT = 16043  # 1 plus the last four digits of your student ID
MAX_PENDING = 5
MAX_LINE = 256

def main():
    try:
        # Create a socket.
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except socket.error as e:
        print(f"Error creating socket: {e}")
        sys.exit(1)

    try:
        # Bind the socket.
        s.bind(('', SERVER_PORT))
    except socket.error as e:
        print(f"bind() failed: {e}")
        s.close()
        sys.exit(1)

    try:
        # Listen on the Socket.
        s.listen(MAX_PENDING)
    except socket.error as e:
        print(f"Error listening on socket: {e}")
        s.close()
        sys.exit(1)

    print("Waiting for a client to connect...")
    while True:
        try:
            # Accept connections.
            conn, addr = s.accept()
            print("Client Connected.")
            
            # Send and receive data.
            data = conn.recv(MAX_LINE)
            if not data:
                break
            conn.sendall(data)
        except socket.error as e:
            print(f"Error in connection: {e}")
        finally:
            conn.close()
            print("Client Closed.")

    s.close()

if __name__ == "__main__":
    main()
